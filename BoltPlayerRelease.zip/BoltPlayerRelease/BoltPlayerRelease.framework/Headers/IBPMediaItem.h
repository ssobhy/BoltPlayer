//
//  IPBMediaItem.h
//  BoltPlayerPlugin
//
//  Created by Moamen on 8/9/18.
//  Copyright © 2018 Inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BoltPlay/IBPBoltPlay.h>

@interface IBPMediaItem : NSObject

@property(nonatomic) NSString *contentId;
@property(nonatomic) NSString *file;
@property(nonatomic) NSString *adUrl;
@property(nonatomic) IBPContentType contentType;
@property(nonatomic) NSString *title;
@property(nonatomic) NSString *desc;
@property(nonatomic) NSInteger duration;
@property(nonatomic) NSArray<NSString *> *keywords;
@property(nonatomic) NSString *drmLicenseUrl;
@property(nonatomic) NSDictionary<NSString*,NSString*> *drmLicenseRequestProperties;

- (instancetype) initWithContentId:(NSString *)contentId
                          andFile:(NSString *)file
                           andAdUrle:(NSString *)adUrl
                         andContentType:(IBPContentType )contentType
                         andTitle:(NSString *)title
                         andDesc:(NSString *)desc
                         andDuration:(NSInteger )duration
                 andKeywords: (NSArray<NSString *> *)keywords
                     drmLicenseUrl:(NSString*)drmLicenseUrl
drmLicenseRequestProperties:(NSDictionary<NSString*,NSString*> *)drmLicenseRequestProperties;


@end
