//
//  IBPRBoltPlayerControlsView.h
//  DRMSample
//
//  Created by inmobly on 12/7/16.
//  Copyright © 2016 Inmobly. All rights reserved.
//



#import <UIKit/UIKit.h>

@protocol IBPRBoltPlayerControlsViewDelegate <NSObject>
- (void)didPressPlay;
- (void)didPressPause;
- (void)didSeekToValue:(NSTimeInterval)value;
@end

@interface IBPRBoltPlayerControlsView : UIView

@property(nonatomic, weak) id<IBPRBoltPlayerControlsViewDelegate> delegate;

- (void)initSeekBarWithDuration:(NSInteger)duration;
- (void)setSeekBarCurrentTime:(NSInteger)currentTime;

@end
