#import <UIKit/UIKit.h>
#import <AVFoundation/AVPlayerItem.h>
#import "IBPRBoltPlayerControlsView.h"


@protocol IBPRBoltPlayerViewDelegate;

typedef enum : NSUInteger {
    IBPRBOLTPLAYER_CONTENT_TYPE_SINGLE_FILE = 0,
    IBPRBOLTPLAYER_CONTENT_TYPE_WIDEVINE = 1,
    IBPRBOLTPLAYER_CONTENT_TYPE_HLS = 2,
    IBPRBOLTPLAYER_CONTENT_TYPE_HLS_LIVE = 3,
    IBPRBOLTPLAYER_CONTENT_TYPE_UNKNOWN = -2,
} IBPRBoltPlayerContentType;

@interface IBPRBoltPlayer : UIView

@property (nonatomic, strong) AVPlayer *player;
@property (nonatomic,strong) AVPlayerItem *playerItem;
@property (nonatomic,weak) id<IBPRBoltPlayerViewDelegate> playbackViewDelegate;
@property (nonatomic) id<IBPRBoltPlayerViewDelegate> pluginDelegate;
@property (nonatomic) IBPRBoltPlayerControlsView* playerControlsView;
@property (nonatomic) BOOL enableDefaultControls;
@property (nonatomic) BOOL autoPlay;


- (void)prepareWithVideoId:(NSString *)videoId
                  videoUrl:(NSString *) videoUrl
                     adUrl:(NSString *) adUrl
               contentType:(IBPRBoltPlayerContentType) boltplayContentType
                licenseUrl:(NSString *)licenseUrl
        licenseRequestInfo:(NSDictionary *)licenseRequestInfo;

-(float) getPlayedPercentage;
-(float) getBufferedPercentage;
- (void) play;
- (void) pause;
- (void) stop;
- (void) restart;
- (void) seekToTime:(NSTimeInterval)time;
- (void) clear;

@end

@protocol IBPRBoltPlayerViewDelegate <NSObject>
@optional
- (void)playbackView:(IBPRBoltPlayer *)videoPlayer didUpdatePlayBackProgress:(CGFloat)progress;
- (void)playbackView:(IBPRBoltPlayer *)videoPlayer playerReadyWithPlayerItemDuration:(CMTime)playerItemDuration;
- (void)playbackView:(IBPRBoltPlayer *)videoPlayer playerFailedWithError:(NSError*)error;
- (void)playbackView:(IBPRBoltPlayer *)videoPlayer finishedWith:(float)watchedPercent bufferedPercent:(float)bufferedPercent;
- (void)playerItemDidReachEndWithPlayBackView:(IBPRBoltPlayer *)videoPlayer;

@end
