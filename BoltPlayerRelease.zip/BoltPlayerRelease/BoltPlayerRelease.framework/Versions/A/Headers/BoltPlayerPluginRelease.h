//
//  BoltPlayerPlugin.h
//  BoltPlayerPlugin
//
//  Created by Inmobly on 12/6/16.
//  Copyright © 2016 Inmobly. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BoltPlayerPlugin.
FOUNDATION_EXPORT double BoltPlayerPluginVersionNumber;

//! Project version string for BoltPlayerPlugin.
FOUNDATION_EXPORT const unsigned char BoltPlayerPluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BoltPlayerPlugin/PublicHeader.h>

#import <BoltPlayerPlugin/IBPRBoltPlayerControlsView.h>
#import <BoltPlayerPlugin/IBPRBoltPlayer.h>
#import <BoltPlayerPlugin/IBPDrmBoltPlayPlugin.h>
#import <BoltPlayerPlugin/IBPDrmBoltPlay.h>
#import <BoltPlayerPlugin/IBPRBoltPlayerPlugin.h>

